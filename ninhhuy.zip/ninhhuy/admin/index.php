<?php
	include("../includes/config.php");
	session_start();
	if(isset($_SESSION['admin_login'])) {
		if($_SESSION['admin_login'] == true) {
			//select last 5 retailers
			$query_selectRetailer = "SELECT * FROM retailer,area WHERE retailer.area_id=area.area_id ORDER BY retailer_id DESC LIMIT 5";
			$result_selectRetailer = mysqli_query($con,$query_selectRetailer);
			//select last 5 manufacturers
			$query_selectManufacturer = "SELECT * FROM manufacturer ORDER BY man_id DESC LIMIT 5";
			$result_selectManufacturer = mysqli_query($con,$query_selectManufacturer);
			//select last 5 products
			$query_selectProducts = "SELECT * FROM products,categories,unit WHERE products.pro_cat=categories.cat_id AND products.unit=unit.id ORDER BY pro_id DESC LIMIT 5";
			$result_selectProducts = mysqli_query($con,$query_selectProducts);
		}
		else {
			header('Location:../index.php');
		}
	}
	else {
		header('Location:../index.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title> Admin: Trang Chủ </title>
	<link rel="stylesheet" href="../includes/main_style.css" >
	<style>
        body {
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 30px;
        }

        .table_displayData {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table_displayData th,
        .table_displayData td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
	<?php
		include("../includes/header.inc.php");
		include("../includes/nav_admin.inc.php");
		include("../includes/aside_admin.inc.php");
	?>
	<section>
		<h1>Xin chào Admin</h1>
		<article>
			<h2>Đối tác Bán Lẻ Mới Thêm</h2>
			<table class="table_displayData">
				<tr>
					<th>STT</th>
					<th>Tên Đăng Nhập</th>
					<th>Mã Khu Vực</th>
					<th>Điện Thoại</th>
					<th>Email</th>
					<th>Địa Chỉ</th>
				</tr>
				<?php $i=1; while($row_selectRetailer = mysqli_fetch_array($result_selectRetailer)) { ?>
				<tr>
					<td> <?php echo $i; ?> </td>
					<td> <?php echo $row_selectRetailer['username']; ?> </td>
					<td> <?php echo $row_selectRetailer['area_code']; ?> </td>
					<td> <?php echo $row_selectRetailer['phone']; ?> </td>
					<td> <?php echo $row_selectRetailer['email']; ?> </td>
					<td> <?php echo $row_selectRetailer['address']; ?> </td>
				</tr>
				<?php $i++; } ?>
			</table>
		</article>
		
		<article>
			<h2>Nhà Sản Xuất Mới Thêm</h2>
			<table class="table_displayData">
			<tr>
				<th>STT</th>
				<th>Tên</th>
				<th>Email</th>
				<th>Điện Thoại</th>
				<th>Tên Đăng Nhập</th>
			</tr>
			<?php $i=1; while($row_selectManufacturer = mysqli_fetch_array($result_selectManufacturer)) { ?>
			<tr>
				<td> <?php echo $i; ?> </td>
				<td> <?php echo $row_selectManufacturer['man_name']; ?> </td>
				<td> <?php echo $row_selectManufacturer['man_email']; ?> </td>
				<td> <?php echo $row_selectManufacturer['man_phone']; ?> </td>
				<td> <?php echo $row_selectManufacturer['username']; ?> </td>
			</tr>
			<?php $i++; } ?>
		</table>
		</article>
		
		<article>
			<h2>Sản Phẩm Mới Thêm</h2>
			<table class="table_displayData">
			<tr>
				<th> Mã </th>
				<th> Tên </th>
				<th> Giá </th>
				<th> Đơn Vị </th>
				<th> Danh Mục </th>
				<th> Số Lượng </th>
			</tr>
			<?php $i=1; while($row_selectProducts = mysqli_fetch_array($result_selectProducts)) { ?>
			<tr>
				<td> <?php echo $row_selectProducts['pro_id']; ?> </td>
				<td> <?php echo $row_selectProducts['pro_name']; ?> </td>
				<td> <?php echo $row_selectProducts['pro_price']; ?> </td>
				<td> <?php echo $row_selectProducts['unit_name']; ?> </td>
				<td> <?php echo $row_selectProducts['cat_name']; ?> </td>
				<td> <?php if($row_selectProducts['quantity'] == NULL){ echo "Không có";} else {echo $row_selectProducts['quantity'];} ?> </td>
			</tr>
			<?php $i++; } ?>
		</table>
		</article>
	</section>
	<?php
		include("../includes/footer.inc.php");
	?>
</body>
</html>
