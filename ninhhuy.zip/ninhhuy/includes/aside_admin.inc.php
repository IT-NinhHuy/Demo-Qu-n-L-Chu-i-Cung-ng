<table class="table_mainWrapper">
<tr>
<td id="td_aside">

<aside>
			<a href="../admin/add_product.php">Thêm Sản phẩm</a><!--
        --><a href="../admin/add_retailer.php">Thêm Nhà bán lẻ</a><!--
        --><a href="../admin/add_manufacturer.php">Thêm Nhà sản xuất</a><!--
        --><a href="../admin/add_distributor.php">Thêm Nhà phân phối</a><!--
        --><a href="../admin/view_unit.php">Quản lý Đơn vị</a><!--
        --><a href="../admin/view_category.php">Quản lý Loại Sản Phẩm</a><!--
        --><a href="../admin/view_area.php">Quản lý Khu vực</a><!--
        --><a href="../admin/change_password.php">Thay Đổi Mật khẩu</a>
</aside>

</td>
<td id="td_section">

<a href="../logout.php"><input type="button" value="Đăng xuất" class="submit_button" style="float:right;margin:10px;"/></a>