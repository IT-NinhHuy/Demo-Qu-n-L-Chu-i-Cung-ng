<table class="table_mainWrapper">
<tr>
<td id="td_aside">

<aside>
			<a href="../manufacturer/edit_profile.php">Chỉnh sửa Hồ sơ</a><!--
        --><a href="../manufacturer/add_product.php">Thêm Sản Phẩm</a><!--
        --><a href="../manufacturer/manage_stock.php">Quản lý Kho hàng</a><!--
        --><a href="../manufacturer/view_unit.php">Quản lý Đơn vị</a><!--
        --><a href="../manufacturer/view_category.php">Quản lý Loại Sản Phẩm</a>
</aside>

</td>
<td id="td_section">
<a href="../logout.php"><input type="button" value="Đăng xuất" class="submit_button" style="float:right;margin:10px;"/></a>