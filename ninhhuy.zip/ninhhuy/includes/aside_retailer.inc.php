<table class="table_mainWrapper">
<tr>
<td id="td_aside">

<aside>
	<a href="../retailer/order_items.php">Tạo đơn đặt hàng mới</a><!--
	--><a href="../retailer/edit_profile.php">Chỉnh sửa thông tin của tôi</a>
</aside>

</td>
<td id="td_section">
<a href="../logout.php"><input type="button" value="Đăng xuất" class="submit_button" style="float:right;margin:10px;"/></a>