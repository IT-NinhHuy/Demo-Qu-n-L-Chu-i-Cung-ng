<nav>
	<a href="../admin/index.php">Trang chủ</a><!--
	--><a href="../admin/view_retailer.php">Nhà bán lẻ</a><!--
	--><a href="../admin/view_manufacturer.php">Nhà sản xuất</a><!--
	--><a href="../admin/view_distributor.php">Nhà phân phối</a><!--
	--><a href="../admin/view_products.php">Sản phẩm</a><!--
	--><a href="../admin/view_orders.php">Đơn đặt hàng</a><!--
	--><a href="../admin/view_invoice.php">Hóa đơn</a>
</nav>
