<nav>
	<a href="index.php">Trang chủ</a>
	<a href="../manufacturer/view_retailer.php">Nhà bán lẻ</a>
	<a href="../manufacturer/view_distributor.php">Nhà phân phối</a>
	<a href="../manufacturer/view_products.php">Sản phẩm</a>
	<a href="../manufacturer/view_orders.php">Đơn đặt hàng</a>
	<a href="../manufacturer/view_invoice.php">Hóa đơn</a>
</nav>
