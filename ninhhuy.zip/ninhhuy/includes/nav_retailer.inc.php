<nav>
	<a href="../retailer/index.php">Trang chủ</a>
	<a href="../retailer/view_products.php">Sản phẩm</a>
	<a href="../retailer/view_my_orders.php">Đơn đặt hàng của tôi</a>
	<a href="../retailer/view_my_invoices.php">Hóa đơn của tôi</a>
</nav>
