<?php
	function validate_email($email) {
		if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
			return true;
		}
		else {
			return "* Email không hợp lệ";
		}
	}
	function validate_name($name) {
		// Cho phép ký tự chữ cái, dấu cách và các ký tự tiếng Việt
		if(preg_match("/^[a-zA-ZÀ-Ỹà-ỹ ]{1,50}$/u", $name)) {
			return true;
		} else {
			return "* Tên không hợp lệ";
		}
	}
	
	function validate_password($password) {
		if(strlen($password) > 4 && strlen($password) < 31) {
			return true;
		}
		else {
			return "* Chỉ cho phép 5-30 ký tự ";
		}
	}
	function validate_phone($phone) {
		if(preg_match("/^[0-9]{10}$/",$phone)) {
			return true;
		}
		else {
			return "* Số điện thoại không hợp lệ";
		}
	}
	function validate_number($number) {
		if(preg_match("/^[0-9]*$/",$number)) {
			return true;
		}
		else {
			return "* Số không hợp lệ";
		}
	}
	function validate_price($price) {
		if(preg_match("/^[0-9.]*$/",$price)) {
			return true;
		}
		else {
			return "* Giá không hợp lệ";
		}
	}
	function validate_username($username) {
		if(preg_match("/^[a-zA-Z0-9]{5,14}$/",$username)) {
			return true;
		}
		else {
			return "* 5-14 ký tự, chỉ được phép bảng chữ cái & số";
		}
	}
?>