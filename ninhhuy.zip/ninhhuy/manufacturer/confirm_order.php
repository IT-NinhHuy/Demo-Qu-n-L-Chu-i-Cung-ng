<?php
error_reporting(0);
require("../includes/config.php");
session_start();

if (isset($_SESSION['manufacturer_login'])) {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        // Lấy thông tin về số lượng sản phẩm trong đơn hàng
        $queryOrderQuantity = "SELECT pro_id, quantity FROM order_items WHERE order_id='$id'";
        $resultOrderQuantity = mysqli_query($con, $queryOrderQuantity);

        // Kiểm tra số lượng tồn kho và cập nhật số lượng hàng tồn kho
        while ($rowOrderQuantity = mysqli_fetch_assoc($resultOrderQuantity)) {
            $pro_id = $rowOrderQuantity['pro_id'];
            $orderQuantity = $rowOrderQuantity['quantity'];

            // Lấy thông tin về số lượng tồn kho hiện tại của sản phẩm
            $queryAvailableQuantity = "SELECT quantity FROM products WHERE pro_id='$pro_id'";
            $resultAvailableQuantity = mysqli_query($con, $queryAvailableQuantity);
            $rowAvailableQuantity = mysqli_fetch_assoc($resultAvailableQuantity);

            if ($rowAvailableQuantity && $rowAvailableQuantity['quantity'] !== null) {
                $availableQuantity = $rowAvailableQuantity['quantity'];

                // Kiểm tra xem có đủ số lượng tồn kho không
                if ($availableQuantity >= $orderQuantity) {
                    // Cập nhật số lượng tồn kho mới
                    $newQuantity = $availableQuantity - $orderQuantity;
                    $queryUpdateQuantity = "UPDATE products SET quantity='$newQuantity' WHERE pro_id='$pro_id'";
                    $resultUpdateQuantity = mysqli_query($con, $queryUpdateQuantity);

                    if (!$resultUpdateQuantity) {
                        echo "<script> alert(\"Có lỗi khi cập nhật số lượng tồn kho\"); </script>";
                    }
                } else {
                    echo "<script> alert(\"Số lượng tồn kho không đủ để xác nhận đơn hàng\"); </script>";
                    header("refresh:0;url=view_orders.php");
                    exit;
                }
            }
        }

        // Cập nhật trạng thái xác nhận của đơn hàng
        $queryConfirm = "UPDATE orders SET approved=1 WHERE order_id='$id'";
        $resultConfirm = mysqli_query($con, $queryConfirm);

        if ($resultConfirm) {
            echo "<script> alert(\"Đơn hàng đã được xác nhận\"); </script>";
            header("refresh:0;url=view_orders.php");
        } else {
            echo "<script> alert(\"Có một số vấn đề khi xác nhận đơn hàng.\"); </script>";
            header("refresh:0;url=view_orders.php");
        }
    } else {
        echo "<script> alert(\"Không có thông tin đơn hàng\"); </script>";
        header("refresh:0;url=view_orders.php");
    }
} else {
    header('Location:../index.php');
}
?>
