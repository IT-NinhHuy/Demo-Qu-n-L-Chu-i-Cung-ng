<?php
	include("../includes/config.php");
	include("../includes/validate_data.php");
	session_start();

	if(isset($_SESSION['manufacturer_login'])) {
		$name = $phone = $email = "";
		$nameErr = $phoneErr = $emailErr = $requireErr = $confirmMessage = "";
		$usernameHolder = $phoneHolder = $emailHolder = "";
		$id = $_SESSION['manufacturer_id'];
		$query_selectMan = "SELECT * FROM manufacturer WHERE man_id='$id'";
		$result_selectMan = mysqli_query($con, $query_selectMan);
		$row_selectMan = mysqli_fetch_array($result_selectMan);

		if ($_SERVER['REQUEST_METHOD'] == "POST") {
			if (!empty($_POST['txtManufacturerName'])) {
				$nameHolder = $_POST['txtManufacturerName'];
				$resultValidate_name = validate_name($_POST['txtManufacturerName']);
				if ($resultValidate_name == 1) {
					$name = $_POST['txtManufacturerName'];
				} else {
					$nameErr = $resultValidate_name;
				}
			}
			if (!empty($_POST['txtManufacturerEmail'])) {
				$emailHolder = $_POST['txtManufacturerEmail'];
				$resultValidate_email = validate_email($_POST['txtManufacturerEmail']);
				if ($resultValidate_email == 1) {
					$email = $_POST['txtManufacturerEmail'];
				} else {
					$emailErr = $resultValidate_email;
				}
			}
			if (!empty($_POST['txtManufacturerPhone'])) {
				$phoneHolder = $_POST['txtManufacturerPhone'];
				$resultValidate_phone = validate_phone($_POST['txtManufacturerPhone']);
				if ($resultValidate_phone == 1) {
					$phone = $_POST['txtManufacturerPhone'];
				} else {
					$phoneErr = $resultValidate_phone;
				}
			}

			// Xử lý tải ảnh lên server
			if (!empty($_FILES['manufacturerImage']['name'])) {
				$targetDir = "../uploads/";
				$targetFile = $targetDir . basename($_FILES['manufacturerImage']['name']);
				$imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

				// Kiểm tra định dạng ảnh
				if ($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png" && $imageFileType != "gif") {
					$requireErr = "Chỉ chấp nhận các định dạng JPG, JPEG, PNG, GIF.";
				} else {
					if (move_uploaded_file($_FILES['manufacturerImage']['tmp_name'], $targetFile)) {
						// Lưu đường dẫn của ảnh vào cơ sở dữ liệu
						$imagePath = "../uploads/" . basename($_FILES['manufacturerImage']['name']);
						$query_updateImage = "UPDATE manufacturer SET man_image='$imagePath' WHERE man_id='$id'";
						mysqli_query($con, $query_updateImage);
					} else {
						$requireErr = "Tải ảnh lên thất bại.";
					}
				}
			}

			if ($name != null && $phone != null) {
				$query_updateMan = "UPDATE manufacturer SET man_name='$name',man_email='$email',man_phone='$phone',man_image='$imagePath' WHERE man_id='$id'";
				if (mysqli_query($con, $query_updateMan)) {
					echo "<script> alert(\"Cập nhật Nhà sản xuất thành công\"); </script>";
					header("Refresh:0");
				} else {
					$requireErr = "Cập nhật Nhà sản xuất thất bại";
				}
			} else {
				$requireErr = "* Tên và Số điện thoại hợp lệ là bắt buộc";
			}
		}
	} else {
		header('Location:../index.php');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title> Chỉnh Sửa Hồ Sơ </title>
	<link rel="stylesheet" href="../includes/main_style.css">
</head>
<body>
	<?php
		include("../includes/header.inc.php");
		include("../includes/nav_manufacturer.inc.php");
		include("../includes/aside_manufacturer.inc.php");
	?>
	<section>
		<h1>Chỉnh Sửa Hồ Sơ</h1>
		<form action="" method="POST" enctype="multipart/form-data" class="form">
			<ul class="form-list">
			<li>
					<!-- Hiển thị ảnh -->
					<div class="label-block"> <label for="currentImage">Ảnh Hiện Tại</label> </div>
					<div class="current-image"> <img src="<?php echo $row_selectMan['man_image']; ?>" alt="Current Image" width="150" height="230"/> </div>
				</li>
				<li>
					<div class="label-block"> <label for="manufacturer:name">Tên</label> </div>
					<div class="input-box"> <input type="text" id="manufacturer:name" name="txtManufacturerName" placeholder="Tên" value="<?php echo $row_selectMan['man_name']; ?>" required /> </div> <span class="error_message"><?php echo $nameErr; ?></span>
				</li>
				<li>
					<div class="label-block"> <label for="manufacturer:email">Email</label> </div>
					<div class="input-box"> <input type="text" id="manufacturer:email" name="txtManufacturerEmail" placeholder="Email" value="<?php echo $row_selectMan['man_email']; ?>" required /> </div> <span class="error_message"><?php echo $emailErr; ?></span>
				</li>
				<li>
					<div class="label-block"> <label for="manufacturer:phone">Số điện thoại</label> </div>
					<div class="input-box"> <input type="text" id="manufacturer:phone" name="txtManufacturerPhone" placeholder="Số điện thoại" value="<?php echo $row_selectMan['man_phone']; ?>" /> </div> <span class="error_message"><?php echo $phoneErr; ?></span>
				</li>
				<li>
					<!-- Thêm ô tải ảnh -->
					<div class="label-block"> <label for="manufacturerImage">Ảnh</label> </div>
					<div class="input-box"> <input type="file" id="manufacturerImage" name="manufacturerImage" accept="image/*" /> </div>
				</li>
				<li>
					<a href="change_password.php"><input type="button" value="Đổi Mật Khẩu" class="submit_button" /></a>
					<input type="submit" value="Cập Nhật Hồ Sơ" class="submit_button" /> <span class="error_message"> <?php echo $requireErr; ?> </span><span class="confirm_message"> <?php echo $confirmMessage; ?> </span>
				</li>
				
			</ul>
		</form>
	</section>
	<?php
		include("../includes/footer.inc.php");
	?>
</body>
</html>
