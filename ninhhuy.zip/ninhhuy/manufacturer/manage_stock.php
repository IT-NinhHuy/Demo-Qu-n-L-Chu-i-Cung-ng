<?php
include("../includes/config.php");
session_start();

if (isset($_SESSION['manufacturer_login']) && $_SESSION['manufacturer_login'] == true) {
    $querySelectProduct = "SELECT * FROM products, unit WHERE products.unit=unit.id AND quantity IS NOT NULL";
    $resultSelectProduct = mysqli_query($con, $querySelectProduct);

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        if (isset($_POST['txtQuantity'])) {
            $arrayQuantity = $_POST['txtQuantity'];
            foreach ($arrayQuantity as $key => $value) {
                $queryUpdateStock = "UPDATE products SET quantity='$value' WHERE pro_id='$key'";
                $result = mysqli_query($con, $queryUpdateStock);
            }
            if (!$result) {
                $requireErr = "Cập nhật Sản phẩm thất bại";
            } else {
                echo "<script> alert(\"Cập nhật Hàng tồn kho thành công\"); </script>";
                header('Refresh:0');
            }
        }
    }
} else {
    header('Location:../index.php');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title> Nhà Sản Xuất: Quản lý kho hàng</title>
    <link rel="stylesheet" href="../includes/main_style.css">
    <style>
        .table_displayData {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table_displayData img {
            max-width: 100px;
            max-height: 100px;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 5px;
        }

        #btnSubmit {
            margin-top: 10px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        #btnSubmit:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <?php
    include("../includes/header.inc.php");
    include("../includes/nav_manufacturer.inc.php");
    include("../includes/aside_manufacturer.inc.php");
    ?>
    <section>
        <h1>Quản lý Hàng tồn kho</h1>
        <form action="" method="POST" class="form">
            <table class="table_displayData" style="margin-top:20px;">
                <tr>
                    <th> Mã Sản phẩm </th>
                    <th> Hình ảnh </th>
                    <th> Tên </th>
                    <th> Đơn vị </th>
                    <th> Số lượng </th>
                </tr>
                <?php while ($rowSelectProduct = mysqli_fetch_array($resultSelectProduct)) { ?>
                    <tr>
                        <td><?php echo $rowSelectProduct['pro_id']; ?></td>
                        <td><img src="../uploads/<?php echo $rowSelectProduct['pro_image']; ?>" alt="<?php echo $rowSelectProduct['pro_name']; ?>" style="max-width: 150px; max-height: 80px;"></td>
                        <td><?php echo $rowSelectProduct['pro_name']; ?></td>
                        <td><?php echo $rowSelectProduct['unit_name']; ?></td>
                        <td><input type="text" name="txtQuantity[<?php echo $rowSelectProduct['pro_id']; ?>]" value="<?php echo $rowSelectProduct['quantity']; ?>" size="10" /></td>
                    </tr>
                <?php } ?>
            </table>
            <input id="btnSubmit" type="submit" value="Cập nhật Hàng tồn kho" class="submit_button" />
        </form>
    </section>
    <?php
    include("../includes/footer.inc.php");
    ?>
</body>

</html>
