<?php
include("../includes/config.php");
session_start();

if (isset($_SESSION['manufacturer_login'])) {
    $query_selectProducts = "SELECT * FROM products,categories,unit WHERE products.pro_cat=categories.cat_id AND products.unit=unit.id AND products.status!=0 ORDER BY pro_id";
    $result_selectProducts = mysqli_query($con, $query_selectProducts);

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        if (isset($_POST['chkId'])) {
            $chkId = $_POST['chkId'];
            foreach ($chkId as $id) {
                $query_deleteProduct = "UPDATE products SET status = 0 WHERE pro_id='$id'";
                $result = mysqli_query($con, $query_deleteProduct);
            }
            if (!$result) {
                echo "<script> alert(\"Không thể xóa sản phẩm đã được đặt hàng bởi Nhà bán lẻ\"); </script>";
                header('Refresh:0');
            } else {
                echo "<script> alert(\"Xóa Sản Phẩm Thành Công\"); </script>";
                header('Refresh:0');
            }
        }
    }
} else {
    header('Location:../index.php');
}
?>
<!DOCTYPE html>
<html>

<head>
    <title> Xem Sản Phẩm </title>
    <link rel="stylesheet" href="../includes/main_style.css">
    <script language="JavaScript">
        function toggle(source) {
            checkboxes = document.getElementsByName('chkId[]');
            for (var i = 0, n = checkboxes.length; i < n; i++) {
                checkboxes[i].checked = source.checked;
            }
        }
    </script>
    <style>
        .table_displayData {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
    </style>
    
</head>

<body>
    <?php
    include("../includes/header.inc.php");
    include("../includes/nav_manufacturer.inc.php");
    include("../includes/aside_manufacturer.inc.php");
    ?>
    <section>
        <h1>Xem Sản Phẩm</h1>
        <form action="" method="POST" class="form">
            <table class="table_displayData">
                <tr>
                    <th> <input type="checkbox" onClick="toggle(this)" /> </th>
                    <th> Mã </th>
                    <th> Hình Ảnh </th>
                    <th> Tên </th>
                    <th> Giá </th>
                    <th> Đơn Vị </th>
                    <th> Danh Mục </th>
                    <th> Số Lượng </th>
                    
                    <th> Chỉnh Sửa </th>
                </tr>
                <?php $i = 1;
                while ($row_selectProducts = mysqli_fetch_array($result_selectProducts)) { ?>
                    <tr>
                        <td> <input type="checkbox" name="chkId[]" value="<?php echo $row_selectProducts['pro_id']; ?>" /> </td>
                        <td> <?php echo $row_selectProducts['pro_id']; ?> </td>
                        <td> <img src="../uploads/<?php echo $row_selectProducts['pro_image']; ?>" alt="product_image" style="width: 130px; height: 100px;" /> </td>
                        <td> <?php echo $row_selectProducts['pro_name']; ?> </td>
                        <td> <?php echo $row_selectProducts['pro_price']; ?> </td>
                        <td> <?php echo $row_selectProducts['unit_name']; ?> </td>
                        <td> <?php echo $row_selectProducts['cat_name']; ?> </td>
                        <td> <?php if ($row_selectProducts['quantity'] == NULL) {
                                    echo "N/A";
                                } else {
                                    echo $row_selectProducts['quantity'];
                                } ?> </td>
                        
                        <td> <a href="edit_product.php?id=<?php echo $row_selectProducts['pro_id']; ?>"><img src="../images/edit.png" alt="edit" /></a> </td>
                    </tr>
                <?php $i++;
                } ?>
            </table>
            <input type="submit" value="Xóa" class="submit_button" />
        </form>
    </section>
    <?php
    include("../includes/footer.inc.php");
    ?>
</body>

</html>
