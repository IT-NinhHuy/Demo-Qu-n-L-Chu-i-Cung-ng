<?php
    require("../includes/config.php");
    session_start();

    if(isset($_SESSION['retailer_login']) || isset($_SESSION['admin_login'])) {
        // Thêm chức năng tìm kiếm
        $searchKeyword = isset($_POST['searchProduct']) ? $_POST['searchProduct'] : '';
        $query_selectProducts = "SELECT * FROM products WHERE pro_name LIKE '%$searchKeyword%' AND status != 0";
        $result_selectProducts = mysqli_query($con, $query_selectProducts);
    } else {
        header('Location:../index.php');
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Đơn hàng đặt hàng</title>
    <link rel="stylesheet" href="../includes/main_style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 30px;
        }

        .table_displayData {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table_displayData th,
        .table_displayData td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input[type=text] {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .search-container button {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 100px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        #btnSubmit {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input[type=text] {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .search-container button {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 100px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <?php
        include("../includes/header.inc.php");
        include("../includes/nav_retailer.inc.php");
        include("../includes/aside_retailer.inc.php");
    ?>
    <section>
        <h1>Đơn hàng đặt hàng</h1>
        <form action="insert_man_order.php" method="POST" class="form">
            <!-- Thêm ô tìm kiếm -->
            <div class="search-container">
                <input type="text" name="searchProduct" placeholder="Tìm kiếm sản phẩm...">
                <button type="submit">Tìm kiếm</button>
            </div>
            <table class="table_displayData">
                <tr>
                    <th>Mã Sản Phẩm</th>
                    <th>Ảnh</th>
                    <th>Tên</th>
                    <th>Giá sản phẩm</th>
                    <th>Số lượng trong kho</th>
                    <th>Số lượng đặt hàng</th>
                    <th>Giá</th>
                </tr>
                <?php while($row_selectProducts = mysqli_fetch_array($result_selectProducts)) { ?>
                    <tr>
                        <td><?php echo $row_selectProducts['pro_id']; ?></td>
                        <td><img src="../uploads/<?php echo $row_selectProducts['pro_image']; ?>" alt="product_image" style="width: 120px; height: 100px;"></td>
                        <td><?php echo $row_selectProducts['pro_name']; ?></td>
                        <td><?php echo $row_selectProducts['pro_price']; ?></td>
                        <td><?php echo ($row_selectProducts['quantity'] == NULL) ? "N/A" : $row_selectProducts['quantity']; ?></td>
                        <td><input type="text" class="quantity" id="<?php echo $row_selectProducts['pro_id']; ?>" name="<?php echo "txtQuantity".$row_selectProducts['pro_id']; ?>" /></td>
                        <td><div id="<?php echo "totalPrice".$row_selectProducts['pro_id']; ?>"></div></td>
                    </tr>
                <?php } ?>
                <tr>
                    <td colspan="5" style="text-align:right;">Tổng tiền cần thanh toán:</td>
                    <td><input type="text" size="20" id="txtFinalAmount" name="total_price" readonly="readonly" value="" /></td>
                </tr>
            </table>
            <input id="btnSubmit" type="submit" value="Đặt Hàng" class="submit_button" onclick="return validateForm();" />
        </form>
    </section>
    <?php
        include("../includes/footer.inc.php");
    ?>
    <script type="text/javascript" src="../includes/jquery.js"></script>
    <script type="text/javascript" src="order_items.js"></script>
    <script>
        function validateForm() {
            var quantities = document.getElementsByClassName("quantity");
            var isAnyQuantityEntered = false;

            for (var i = 0; i < quantities.length; i++) {
                if (quantities[i].value !== "" && parseInt(quantities[i].value) <= 0) {
                    alert("Vui lòng nhập số lượng lớn hơn 0 cho ít nhất một sản phẩm.");
                    return false;
                }

                if (quantities[i].value !== "") {
                    isAnyQuantityEntered = true;
                }
            }

            if (!isAnyQuantityEntered) {
                alert("Vui lòng nhập số lượng cho ít nhất một sản phẩm.");
                return false;
            }

            return true;
        }
    </script>
</body>
</html>
