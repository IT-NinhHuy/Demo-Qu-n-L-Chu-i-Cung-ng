<?php
include("../includes/config.php");
session_start();

// Thêm các biến cần thiết để phân trang
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
$perPage = 10; // Số sản phẩm hiển thị trên mỗi trang
$startFrom = ($currentPage - 1) * $perPage;

// Khởi tạo câu truy vấn SELECT
$query_selectProducts = "SELECT * FROM products,categories,unit 
                         WHERE products.pro_cat=categories.cat_id 
                         AND products.unit=unit.id 
                         AND products.status!=0 ";

// Thêm tìm kiếm nếu có từ khóa
$searchKeyword = isset($_POST['searchProduct']) ? $_POST['searchProduct'] : '';
if (!empty($searchKeyword)) {
    $query_selectProducts .= " AND (products.pro_name LIKE '%$searchKeyword%' )";
}

$query_selectProducts .= " ORDER BY pro_id LIMIT $startFrom, $perPage";

$result_selectProducts = mysqli_query($con, $query_selectProducts);

// Tổng số sản phẩm
$totalProducts = mysqli_num_rows(mysqli_query($con, "SELECT * FROM products,categories,unit WHERE products.pro_cat=categories.cat_id AND products.unit=unit.id AND products.status!=0"));
$totalPages = ceil($totalProducts / $perPage);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Xem Sản Phẩm</title>
    <link rel="stylesheet" href="../includes/main_style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
        }

        .container {
            margin-top: 30px;
        }

        .table_displayData {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table_displayData th,
        .table_displayData td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a {
            color: black;
            padding: 8px 16px;
            text-decoration: none;
            transition: background-color .3s;
            border: 1px solid #ddd;
            margin: 0 4px;
        }

        .pagination a.active {
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
        }

        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }

        .search-container {
            margin-bottom: 20px;
        }

        .search-container input[type=text] {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .search-container button {
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 8px;
            width: 100px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php
    include("../includes/header.inc.php");
    include("../includes/nav_retailer.inc.php");
    include("../includes/aside_retailer.inc.php");
    ?>
    <section>
        <h1>Xem Sản Phẩm</h1>
        <form action="" method="POST" class="form">
            <div class="search-container">
                <label for="searchProduct">Tìm kiếm sản phẩm:</label>
                <input type="text" id="searchProduct" name="searchProduct" placeholder="Nhập tên sản phẩm">
                <input type="submit" value="Tìm kiếm" class="submit_button">
            </div>
            <table class="table_displayData">
                <tr>
                    <th> Mã </th>
                    <th> Hình Ảnh </th>
                    <th> Tên </th>
                    <th> Giá </th>
                    <th> Đơn Vị </th>
                    <th> Danh Mục </th>
                </tr>
                <?php while ($row_selectProducts = mysqli_fetch_array($result_selectProducts)) { ?>
                    <tr>
                        <td> <?php echo $row_selectProducts['pro_id']; ?> </td>
                        <td> <img src="../uploads/<?php echo $row_selectProducts['pro_image']; ?>" alt="product_image" style="width: 120px; height: 100px;" /> </td>
                        <td> <?php echo $row_selectProducts['pro_name']; ?> </td>
                        <td> <?php echo $row_selectProducts['pro_price']; ?> </td>
                        <td> <?php echo $row_selectProducts['unit_name']; ?> </td>
                        <td> <?php echo $row_selectProducts['cat_name']; ?> </td>
                    </tr>
                <?php } ?>
            </table>
        </form>

        <!-- Hiển thị nút phân trang -->
        <div class="pagination">
            <?php
            for ($i = 1; $i <= $totalPages; $i++) {
                $active_class = ($i == $currentPage) ? 'active' : '';
                echo "<a class='$active_class' href='view_products.php?page=$i'>$i</a>";
            }
            ?>
        </div>
    </section>
    <?php
    include("../includes/footer.inc.php");
    ?>
</body>

</html>
